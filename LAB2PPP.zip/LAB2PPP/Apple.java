public class Apple implements FabricanteCelular{
    protected String modelo;

    public Apple() {

    }

    public Celular constroiCelular(String modelo){
        if(modelo.equals("IphoneX")){
            return new IphoneX();
        } else {
            return new IphoneS();
        }
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
}
