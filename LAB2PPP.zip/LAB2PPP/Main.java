public class Main {

    public static void main(String[] args) {
        FabricanteCelular apple = FabricanteCelularSingleton.get
        Celular meuIphoneS = apple.constroiCelular("Iphone S");
        Celular mariaIphoneS = apple.constroiCelular("Iphone S");

        meuIphoneS.fazLigacao();
        mariaIphoneS.tiraFoto();
    }
}
