public class FabricanteCelularSingleton {
    private FabricanteCelular samsung;
    private FabricanteCelular apple;

    public FabricanteCelular getFabricaSamsung(){
        if(samsung == null){
            samsung = new Samsung();
        }

        return samsung;
    }

    public FabricanteCelular getFabricaApple(){
        if(apple == null){
            apple = new Apple();
        }

        return apple;
    }


}
