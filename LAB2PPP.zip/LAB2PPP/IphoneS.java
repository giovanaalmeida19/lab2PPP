public class IphoneS implements Celular{
    public void fazLigacao(){
        System.out.println("Ligação Iphone S");
    }

    public void tiraFoto(){
        System.out.println("Foto Iphone S");
    }
}
