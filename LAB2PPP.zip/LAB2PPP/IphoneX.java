public class IphoneX implements Celular{
    public void fazLigacao(){

    }

    public void tiraFoto(){

    }
}
