public class Samsung implements FabricanteCelular {
    protected String modelo;
    public Samsung(){

    }

    /*public void setModelo(String modelo){
        this.modelo = modelo;
    }

    public String getModelo(){
        return this.modelo;
    }*/
}
